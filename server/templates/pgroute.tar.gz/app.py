#!/usr/bin/env python3
"""
pgRouting Transportation Demo
Demonstrates shortest path, traveling salesman, and isochrone analysis.
Requires PostgreSQL with PostGIS and pgRouting extensions.
"""

import os
from flask import Flask, request, jsonify
from flask_cors import CORS
import psycopg2
from psycopg2.extras import RealDictCursor
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
CORS(app)

DATABASE_URL = os.environ.get('DATABASE_URL', 'postgresql://postgres:postgres@localhost:5432/postgres')

def get_db():
    return psycopg2.connect(DATABASE_URL, cursor_factory=RealDictCursor)

@app.route('/api/health')
def health():
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
        return jsonify({"status": "ok", "database": "connected"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/shortest-path', methods=['POST'])
def shortest_path():
    """Find shortest path between two nodes using Dijkstra."""
    data = request.json or {}
    source = int(data.get('source', 1))
    target = int(data.get('target', 9))

    with get_db() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT seq, node, edge, cost, agg_cost
                FROM pgr_dijkstra(
                    'SELECT id, source, target, cost, reverse_cost FROM edges',
                    %s, %s, directed := true
                )
            """, (source, target))
            path = cur.fetchall()

    return jsonify({
        "source": source,
        "target": target,
        "total_cost": float(path[-1]['agg_cost']) if path else 0,
        "segments": len(path),
        "path": [dict(r) for r in path]
    })

@app.route('/api/tsp', methods=['POST'])
def traveling_salesman():
    """Solve Traveling Salesman Problem."""
    data = request.json or {}
    node_ids = [int(n) for n in data.get('nodes', [1, 3, 5, 7, 9])]

    with get_db() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT seq, node, cost, agg_cost
                FROM pgr_TSP(
                    $$SELECT * FROM pgr_dijkstraCostMatrix(
                        'SELECT id, source, target, cost, reverse_cost FROM edges',
                        %s, directed := false
                    )$$,
                    start_id := %s
                )
            """, (node_ids, node_ids[0]))
            route = cur.fetchall()

    return jsonify({
        "nodes_visited": len(route),
        "total_cost": float(route[-1]['agg_cost']) if route else 0,
        "route": [dict(r) for r in route]
    })

@app.route('/api/isochrone', methods=['POST'])
def isochrone():
    """Calculate reachable area within a cost budget."""
    data = request.json or {}
    source = int(data.get('source', 1))
    max_cost = float(data.get('max_cost', 50))

    with get_db() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT node, agg_cost
                FROM pgr_drivingDistance(
                    'SELECT id, source, target, cost, reverse_cost FROM edges',
                    %s, %s, directed := true
                )
                ORDER BY agg_cost
            """, (source, max_cost))
            reachable = cur.fetchall()

    return jsonify({
        "source": source,
        "max_cost": max_cost,
        "reachable_nodes": len(reachable),
        "nodes": [dict(r) for r in reachable]
    })

@app.route('/api/network-stats')
def network_stats():
    """Get network statistics."""
    with get_db() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT count(*) as cnt FROM edges")
            edges = cur.fetchone()['cnt']
            cur.execute("SELECT count(DISTINCT source) + count(DISTINCT target) as cnt FROM edges")
            nodes = cur.fetchone()['cnt']
            cur.execute("SELECT sum(cost) as total FROM edges")
            total = cur.fetchone()['total']

    return jsonify({
        "edges": edges,
        "nodes": nodes,
        "total_network_cost": float(total or 0)
    })

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)
