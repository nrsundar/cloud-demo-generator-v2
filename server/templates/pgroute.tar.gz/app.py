#!/usr/bin/env python3
"""
pgRouting Transportation Demo - Network Routing Application
Demonstrates shortest path, traveling salesman, and isochrone analysis
using pgRouting on Aurora PostgreSQL.
"""

import os
import json
from flask import Flask, request, jsonify
import psycopg2
from psycopg2.extras import RealDictCursor

app = Flask(__name__)

def get_db():
    return psycopg2.connect(
        os.environ.get('DATABASE_URL', 'postgresql://postgres:postgres@localhost:5432/routing_demo'),
        cursor_factory=RealDictCursor
    )

@app.route('/api/health')
def health():
    return jsonify({"status": "ok"})

@app.route('/api/shortest-path', methods=['POST'])
def shortest_path():
    """Find shortest path between two nodes using Dijkstra's algorithm."""
    data = request.json
    source = data.get('source', 1)
    target = data.get('target', 10)

    with get_db() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT seq, node, edge, cost, agg_cost,
                       ST_AsGeoJSON(the_geom)::json as geometry
                FROM pgr_dijkstra(
                    'SELECT id, source, target, cost, reverse_cost FROM edges',
                    %s, %s, directed := true
                ) AS route
                JOIN edges ON route.edge = edges.id
                ORDER BY seq
            """, (source, target))
            path = cur.fetchall()

    return jsonify({
        "source": source,
        "target": target,
        "total_cost": path[-1]['agg_cost'] if path else 0,
        "segments": len(path),
        "path": [dict(r) for r in path]
    })

@app.route('/api/tsp', methods=['POST'])
def traveling_salesman():
    """Solve Traveling Salesman Problem for a set of locations."""
    data = request.json
    node_ids = data.get('nodes', [1, 5, 10, 15, 20])

    with get_db() as conn:
        with conn.cursor() as cur:
            nodes_str = ','.join(str(n) for n in node_ids)
            cur.execute(f"""
                SELECT seq, node, cost, agg_cost
                FROM pgr_TSP(
                    $$SELECT * FROM pgr_dijkstraCostMatrix(
                        'SELECT id, source, target, cost, reverse_cost FROM edges',
                        ARRAY[{nodes_str}], directed := false
                    )$$,
                    start_id := {node_ids[0]}
                )
            """)
            route = cur.fetchall()

    return jsonify({
        "nodes_visited": len(route),
        "total_cost": route[-1]['agg_cost'] if route else 0,
        "route": [dict(r) for r in route]
    })

@app.route('/api/isochrone', methods=['POST'])
def isochrone():
    """Calculate reachable area within a given cost/time from a point."""
    data = request.json
    source = data.get('source', 1)
    max_cost = data.get('max_cost', 100)

    with get_db() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT node, agg_cost,
                       ST_AsGeoJSON(the_geom)::json as geometry
                FROM pgr_drivingDistance(
                    'SELECT id, source, target, cost, reverse_cost FROM edges',
                    %s, %s, directed := true
                ) AS dd
                JOIN vertices ON dd.node = vertices.id
                ORDER BY agg_cost
            """, (source, max_cost))
            reachable = cur.fetchall()

    return jsonify({
        "source": source,
        "max_cost": max_cost,
        "reachable_nodes": len(reachable),
        "nodes": [dict(r) for r in reachable]
    })

@app.route('/api/network-stats')
def network_stats():
    """Get network statistics."""
    with get_db() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT count(*) as edge_count FROM edges")
            edges = cur.fetchone()
            cur.execute("SELECT count(*) as node_count FROM vertices")
            nodes = cur.fetchone()
            cur.execute("SELECT sum(cost) as total_length FROM edges")
            length = cur.fetchone()

    return jsonify({
        "edges": edges['edge_count'],
        "nodes": nodes['node_count'],
        "total_network_length": float(length['total_length'] or 0)
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
