# Data Sources

## Sample Network Data
The sample transportation network data is synthetic, representing a simplified grid
of roads and intersections in the San Francisco area for demonstration purposes.

## pgRouting Extensions
- pgRouting: https://pgrouting.org/
- PostGIS: https://postgis.net/ (required by pgRouting)
