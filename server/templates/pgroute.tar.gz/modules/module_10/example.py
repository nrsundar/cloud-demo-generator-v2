#!/usr/bin/env python3
"""Module 10: Performance and Scaling - Practical implementation example."""

import psycopg2
from psycopg2.extras import RealDictCursor
import os
import time

DATABASE_URL = os.environ.get('DATABASE_URL', 'postgresql://postgres:postgres@localhost:5432/routing_demo')

def run_example():
    """Demonstrate Performance and Scaling with pgRouting."""
    with psycopg2.connect(DATABASE_URL, cursor_factory=RealDictCursor) as conn:
        with conn.cursor() as cur:
            start = time.time()
            # Network statistics
            cur.execute("SELECT count(*) as cnt FROM edges")
            edge_count = cur.fetchone()['cnt']
            cur.execute("SELECT count(*) as cnt FROM vertices")
            node_count = cur.fetchone()['cnt']
            elapsed = (time.time() - start) * 1000
            print(f"Module 10: Performance and Scaling")
            print(f"  Network: {edge_count} edges, {node_count} nodes")
            print(f"  Query time: {elapsed:.1f}ms")

if __name__ == "__main__":
    run_example()
