#!/usr/bin/env python3
"""Module 02: Dijkstra's Algorithm - Multiple routing variants."""

import psycopg2
from psycopg2.extras import RealDictCursor
import os
import time

DATABASE_URL = os.environ.get('DATABASE_URL', 'postgresql://postgres:postgres@localhost:5432/routing_demo')

def dijkstra_one_to_one(source, target):
    """Standard Dijkstra shortest path."""
    with psycopg2.connect(DATABASE_URL, cursor_factory=RealDictCursor) as conn:
        with conn.cursor() as cur:
            start = time.time()
            cur.execute("""
                SELECT seq, node, edge, cost, agg_cost
                FROM pgr_dijkstra(
                    'SELECT id, source, target, cost, reverse_cost FROM edges',
                    %s, %s, directed := true
                )
            """, (source, target))
            path = cur.fetchall()
            elapsed = (time.time() - start) * 1000
            print(f"Path {source}→{target}: {len(path)} steps, cost={path[-1]['agg_cost']:.1f}, {elapsed:.1f}ms")
            return path

def dijkstra_one_to_many(source, targets):
    """Find shortest paths from one source to multiple targets."""
    with psycopg2.connect(DATABASE_URL, cursor_factory=RealDictCursor) as conn:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT end_vid, agg_cost
                FROM pgr_dijkstraCost(
                    'SELECT id, source, target, cost, reverse_cost FROM edges',
                    %s, %s, directed := true
                )
            """, (source, targets))
            costs = cur.fetchall()
            print(f"\nCosts from node {source}:")
            for c in costs:
                print(f"  → Node {c['end_vid']}: cost={c['agg_cost']:.1f}")

def dijkstra_cost_matrix(nodes):
    """Compute cost matrix between all pairs of nodes."""
    with psycopg2.connect(DATABASE_URL, cursor_factory=RealDictCursor) as conn:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT start_vid, end_vid, agg_cost
                FROM pgr_dijkstraCostMatrix(
                    'SELECT id, source, target, cost, reverse_cost FROM edges',
                    %s, directed := false
                )
                ORDER BY start_vid, end_vid
            """, (nodes,))
            matrix = cur.fetchall()
            print(f"\nCost matrix for nodes {nodes}:")
            for m in matrix:
                print(f"  {m['start_vid']} → {m['end_vid']}: {m['agg_cost']:.1f}")

if __name__ == "__main__":
    dijkstra_one_to_one(1, 9)
    dijkstra_one_to_one(1, 6)
    dijkstra_one_to_many(1, [3, 5, 7, 9])
    dijkstra_cost_matrix([1, 5, 9])
