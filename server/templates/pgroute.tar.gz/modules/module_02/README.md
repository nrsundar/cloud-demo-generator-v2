# Module 02: Dijkstra's Algorithm

## Overview
Dijkstra's algorithm finds the shortest path between nodes in a weighted graph. pgRouting implements several variants optimized for different use cases.

## Variants
| Function | Use Case |
|----------|----------|
| `pgr_dijkstra` | Single source to single target |
| `pgr_dijkstraVia` | Route through multiple waypoints |
| `pgr_dijkstraCost` | Cost only (no path details) |
| `pgr_dijkstraCostMatrix` | Cost matrix between multiple nodes |

## One-to-One
```sql
SELECT * FROM pgr_dijkstra(
    'SELECT id, source, target, cost, reverse_cost FROM edges',
    1, 9, directed := true
);
```

## One-to-Many
```sql
SELECT * FROM pgr_dijkstra(
    'SELECT id, source, target, cost, reverse_cost FROM edges',
    1, ARRAY[5, 7, 9], directed := true
);
```

## Via Points (Waypoints)
```sql
SELECT * FROM pgr_dijkstraVia(
    'SELECT id, source, target, cost, reverse_cost FROM edges',
    ARRAY[1, 5, 9]
);
```

## Performance Tips
- Create indexes on `source` and `target` columns
- Use `pgr_dijkstraCost` when you only need the total cost
- Limit the search area with a bounding box for large networks
