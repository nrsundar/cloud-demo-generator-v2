# Module 03: A* Algorithm

## Overview
A* uses heuristics (straight-line distance) to guide the search toward the target, making it faster than Dijkstra for point-to-point queries on spatial networks.

## Key Function: `pgr_aStar`

### Example Query
```sql
-- A* Algorithm example
SELECT * FROM pgr_aStar(
    'SELECT id, source, target, cost, reverse_cost FROM edges',
    -- parameters specific to this function
);
```

## Use Cases
- Transportation network analysis
- Logistics and delivery optimization
- Urban planning and accessibility studies
- Emergency response routing

## Implementation Notes
- Always ensure network topology is valid before routing
- Use spatial indexes on geometry columns for performance
- Consider directed vs undirected graphs based on your road network
- Test with representative data volumes before production deployment

## Best Practices
1. Validate topology with `pgr_analyzeGraph` before running queries
2. Use cost functions that reflect real-world conditions (distance, time, traffic)
3. Partition large networks by region for better query performance
4. Cache frequently requested routes when possible
5. Monitor query execution plans with `EXPLAIN ANALYZE`
