#!/usr/bin/env python3
"""Module 01: Introduction to pgRouting - Basic connectivity and first query."""

import psycopg2
from psycopg2.extras import RealDictCursor
import os

DATABASE_URL = os.environ.get('DATABASE_URL', 'postgresql://postgres:postgres@localhost:5432/routing_demo')

def check_extensions():
    """Verify pgRouting is installed and working."""
    with psycopg2.connect(DATABASE_URL, cursor_factory=RealDictCursor) as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT pgr_version()")
            version = cur.fetchone()
            print(f"pgRouting version: {version['pgr_version']}")

            cur.execute("SELECT PostGIS_Version()")
            postgis = cur.fetchone()
            print(f"PostGIS version: {postgis['postgis_version']}")

            cur.execute("SELECT count(*) as edges FROM edges")
            edges = cur.fetchone()
            cur.execute("SELECT count(*) as vertices FROM vertices")
            vertices = cur.fetchone()
            print(f"Network: {edges['edges']} edges, {vertices['vertices']} vertices")

def first_shortest_path():
    """Run a basic Dijkstra shortest path query."""
    with psycopg2.connect(DATABASE_URL, cursor_factory=RealDictCursor) as conn:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT seq, node, edge, cost, agg_cost
                FROM pgr_dijkstra(
                    'SELECT id, source, target, cost, reverse_cost FROM edges',
                    1, 9, directed := true
                )
            """)
            path = cur.fetchall()
            print(f"\nShortest path from node 1 to node 9:")
            print(f"  Segments: {len(path)}")
            print(f"  Total cost: {path[-1]['agg_cost']:.2f}" if path else "  No path found")
            for step in path:
                print(f"  Step {step['seq']}: Node {step['node']} (cost: {step['cost']:.2f}, total: {step['agg_cost']:.2f})")

if __name__ == "__main__":
    check_extensions()
    first_shortest_path()
