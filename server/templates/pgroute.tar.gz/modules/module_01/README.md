# Module 01: Introduction to pgRouting

## Overview
pgRouting extends PostGIS/PostgreSQL to provide geospatial routing and network analysis functionality. It enables shortest path queries, traveling salesman solutions, and network flow analysis directly in the database.

## Key Concepts
- **Graph Theory**: Roads as edges, intersections as vertices
- **Cost Functions**: Distance, time, or custom weights on edges
- **Directed vs Undirected**: One-way streets vs bidirectional roads
- **Topology**: How edges connect at vertices

## Setup
```sql
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pgrouting;
```

## Your First Query
```sql
-- Find shortest path from node 1 to node 9
SELECT seq, node, edge, cost, agg_cost
FROM pgr_dijkstra(
    'SELECT id, source, target, cost, reverse_cost FROM edges',
    1, 9, directed := true
);
```

## When to Use pgRouting
- Fleet management and logistics optimization
- Delivery route planning
- Emergency response routing
- Urban transportation analysis
- Network infrastructure planning
