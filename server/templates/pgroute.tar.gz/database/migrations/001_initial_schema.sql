-- pgRouting initial schema
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pgrouting;

CREATE TABLE IF NOT EXISTS edges (
    id SERIAL PRIMARY KEY,
    source INTEGER,
    target INTEGER,
    cost DOUBLE PRECISION,
    reverse_cost DOUBLE PRECISION,
    name TEXT,
    road_type VARCHAR(50),
    the_geom GEOMETRY(LINESTRING, 4326)
);

CREATE TABLE IF NOT EXISTS vertices (
    id SERIAL PRIMARY KEY,
    the_geom GEOMETRY(POINT, 4326)
);

CREATE INDEX IF NOT EXISTS idx_edges_geom ON edges USING GIST (the_geom);
CREATE INDEX IF NOT EXISTS idx_edges_source ON edges (source);
CREATE INDEX IF NOT EXISTS idx_edges_target ON edges (target);
