-- Database setup for pgroute-transportation-demo-py
CREATE DATABASE pgroute-transportation-demo-py;
