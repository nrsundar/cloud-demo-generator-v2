-- pgRouting Transportation Demo Database Setup
-- Requires: PostgreSQL with PostGIS and pgRouting extensions

CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pgrouting;

-- Network edges (roads/paths)
CREATE TABLE IF NOT EXISTS edges (
    id SERIAL PRIMARY KEY,
    source INTEGER,
    target INTEGER,
    cost DOUBLE PRECISION,
    reverse_cost DOUBLE PRECISION,
    name TEXT,
    road_type VARCHAR(50),
    the_geom GEOMETRY(LINESTRING, 4326)
);

-- Network vertices (intersections)
CREATE TABLE IF NOT EXISTS vertices (
    id SERIAL PRIMARY KEY,
    the_geom GEOMETRY(POINT, 4326)
);

-- Spatial indexes
CREATE INDEX IF NOT EXISTS idx_edges_geom ON edges USING GIST (the_geom);
CREATE INDEX IF NOT EXISTS idx_vertices_geom ON vertices USING GIST (the_geom);
CREATE INDEX IF NOT EXISTS idx_edges_source ON edges (source);
CREATE INDEX IF NOT EXISTS idx_edges_target ON edges (target);

-- Sample transportation network (simplified grid)
INSERT INTO vertices (id, the_geom) VALUES
    (1, ST_SetSRID(ST_MakePoint(-122.4194, 37.7749), 4326)),
    (2, ST_SetSRID(ST_MakePoint(-122.4094, 37.7749), 4326)),
    (3, ST_SetSRID(ST_MakePoint(-122.3994, 37.7749), 4326)),
    (4, ST_SetSRID(ST_MakePoint(-122.4194, 37.7849), 4326)),
    (5, ST_SetSRID(ST_MakePoint(-122.4094, 37.7849), 4326)),
    (6, ST_SetSRID(ST_MakePoint(-122.3994, 37.7849), 4326)),
    (7, ST_SetSRID(ST_MakePoint(-122.4194, 37.7949), 4326)),
    (8, ST_SetSRID(ST_MakePoint(-122.4094, 37.7949), 4326)),
    (9, ST_SetSRID(ST_MakePoint(-122.3994, 37.7949), 4326)),
    (10, ST_SetSRID(ST_MakePoint(-122.4144, 37.7799), 4326))
ON CONFLICT DO NOTHING;

-- Horizontal edges
INSERT INTO edges (source, target, cost, reverse_cost, name, road_type, the_geom) VALUES
    (1, 2, 10, 10, 'Market St W', 'primary', ST_MakeLine(ST_SetSRID(ST_MakePoint(-122.4194, 37.7749), 4326), ST_SetSRID(ST_MakePoint(-122.4094, 37.7749), 4326))),
    (2, 3, 10, 10, 'Market St E', 'primary', ST_MakeLine(ST_SetSRID(ST_MakePoint(-122.4094, 37.7749), 4326), ST_SetSRID(ST_MakePoint(-122.3994, 37.7749), 4326))),
    (4, 5, 8, 8, 'Mission St W', 'secondary', ST_MakeLine(ST_SetSRID(ST_MakePoint(-122.4194, 37.7849), 4326), ST_SetSRID(ST_MakePoint(-122.4094, 37.7849), 4326))),
    (5, 6, 8, 8, 'Mission St E', 'secondary', ST_MakeLine(ST_SetSRID(ST_MakePoint(-122.4094, 37.7849), 4326), ST_SetSRID(ST_MakePoint(-122.3994, 37.7849), 4326))),
    (7, 8, 12, 12, 'Howard St W', 'tertiary', ST_MakeLine(ST_SetSRID(ST_MakePoint(-122.4194, 37.7949), 4326), ST_SetSRID(ST_MakePoint(-122.4094, 37.7949), 4326))),
    (8, 9, 12, 12, 'Howard St E', 'tertiary', ST_MakeLine(ST_SetSRID(ST_MakePoint(-122.4094, 37.7949), 4326), ST_SetSRID(ST_MakePoint(-122.3994, 37.7949), 4326))),
    (1, 4, 15, 15, '1st Ave N', 'primary', ST_MakeLine(ST_SetSRID(ST_MakePoint(-122.4194, 37.7749), 4326), ST_SetSRID(ST_MakePoint(-122.4194, 37.7849), 4326))),
    (4, 7, 15, 15, '1st Ave S', 'primary', ST_MakeLine(ST_SetSRID(ST_MakePoint(-122.4194, 37.7849), 4326), ST_SetSRID(ST_MakePoint(-122.4194, 37.7949), 4326))),
    (2, 5, 12, 12, '2nd Ave N', 'secondary', ST_MakeLine(ST_SetSRID(ST_MakePoint(-122.4094, 37.7749), 4326), ST_SetSRID(ST_MakePoint(-122.4094, 37.7849), 4326))),
    (5, 8, 12, 12, '2nd Ave S', 'secondary', ST_MakeLine(ST_SetSRID(ST_MakePoint(-122.4094, 37.7849), 4326), ST_SetSRID(ST_MakePoint(-122.4094, 37.7949), 4326))),
    (3, 6, 10, 10, '3rd Ave N', 'tertiary', ST_MakeLine(ST_SetSRID(ST_MakePoint(-122.3994, 37.7749), 4326), ST_SetSRID(ST_MakePoint(-122.3994, 37.7849), 4326))),
    (6, 9, 10, 10, '3rd Ave S', 'tertiary', ST_MakeLine(ST_SetSRID(ST_MakePoint(-122.3994, 37.7849), 4326), ST_SetSRID(ST_MakePoint(-122.3994, 37.7949), 4326))),
    (1, 10, 7, 7, 'Diagonal NW', 'residential', ST_MakeLine(ST_SetSRID(ST_MakePoint(-122.4194, 37.7749), 4326), ST_SetSRID(ST_MakePoint(-122.4144, 37.7799), 4326))),
    (10, 5, 7, 7, 'Diagonal SE', 'residential', ST_MakeLine(ST_SetSRID(ST_MakePoint(-122.4144, 37.7799), 4326), ST_SetSRID(ST_MakePoint(-122.4094, 37.7849), 4326)))
ON CONFLICT DO NOTHING;

SELECT pgr_createTopology('edges', 0.0001, 'the_geom', 'id');
