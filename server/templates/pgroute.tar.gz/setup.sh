#!/bin/bash
set -e

echo "=== pgRouting Transportation Demo Setup ==="

if [ -z "$DATABASE_URL" ]; then
  echo "ERROR: DATABASE_URL not set"
  echo "Export it: export DATABASE_URL=postgresql://postgres:password@endpoint:5432/postgres"
  exit 1
fi

echo "1. Running database setup (extensions + schema)..."
psql "$DATABASE_URL" -f database/setup.sql

echo "2. Installing Python dependencies..."
pip3 install -r requirements.txt

echo "3. Setup complete!"
echo ""
echo "To run the application:"
echo "  python3 app.py"
echo ""
echo "API endpoints:"
echo "  POST /api/shortest-path  - Dijkstra shortest path"
echo "  POST /api/tsp            - Traveling Salesman"
echo "  POST /api/isochrone      - Reachable area analysis"
echo "  GET  /api/network-stats  - Network statistics"
echo "  GET  /api/health         - Health check"
