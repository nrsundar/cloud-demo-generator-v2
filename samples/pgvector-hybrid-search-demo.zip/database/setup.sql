-- Database setup for pgvector-hybrid-search-demo-py
CREATE DATABASE "pgvector_hybrid_search_demo";

-- Enable general PostgreSQL extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pg_stat_statements;
