# Data Sources

## Sample Property Data
The sample property data included in this demo is synthetic and generated for demonstration purposes.
Coordinates are based on real-world locations in the Seattle, WA metropolitan area.

## PostGIS Extensions
- PostGIS: https://postgis.net/
- PostGIS Topology: Topology support for PostGIS
- pg_trgm: Trigram matching for fuzzy text search
