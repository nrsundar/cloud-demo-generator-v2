#!/usr/bin/env python3
"""Module 12: Machine Learning Integration - PostGIS implementation example."""

import psycopg2
from psycopg2.extras import RealDictCursor
import os
import time
import json

DATABASE_URL = os.environ.get('DATABASE_URL', 'postgresql://postgres:postgres@localhost:5432/postgis_demo')

def spatial_search(lon, lat, radius_m=5000):
    """Search properties within radius of a point."""
    with psycopg2.connect(DATABASE_URL, cursor_factory=RealDictCursor) as conn:
        with conn.cursor() as cur:
            start = time.time()
            cur.execute("""
                SELECT id, address, price, property_type,
                       ST_Distance(location::geography, ST_SetSRID(ST_MakePoint(%s, %s), 4326)::geography) as distance_m,
                       ST_AsGeoJSON(location)::json as geojson
                FROM properties
                WHERE ST_DWithin(location::geography, ST_SetSRID(ST_MakePoint(%s, %s), 4326)::geography, %s)
                ORDER BY distance_m
                LIMIT 20
            """, (lon, lat, lon, lat, radius_m))
            results = cur.fetchall()
            elapsed = (time.time() - start) * 1000
            
            print(f"Module 12: Machine Learning Integration")
            print(f"  Search: {radius_m}m radius from ({lat}, {lon})")
            print(f"  Found: {len(results)} properties in {elapsed:.1f}ms")
            for r in results:
                print(f"  - {r['address']}: ${r['price']:,.0f} ({r['distance_m']:.0f}m away)")

if __name__ == "__main__":
    spatial_search(-122.4194, 37.7749, 5000)
