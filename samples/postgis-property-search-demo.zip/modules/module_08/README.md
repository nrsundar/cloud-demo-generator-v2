# Module 08: Search Interface

## Overview
Implement map-based property search with bounding box queries, radius search, and polygon containment using Leaflet.js.

## Key Concepts

### Spatial Queries
```sql
-- Find properties within 5km of a point
SELECT id, address, price,
       ST_Distance(location::geography, ST_SetSRID(ST_MakePoint(-122.4194, 37.7749), 4326)::geography) as distance_m
FROM properties
WHERE ST_DWithin(location::geography, ST_SetSRID(ST_MakePoint(-122.4194, 37.7749), 4326)::geography, 5000)
ORDER BY distance_m;
```

### Performance Optimization
```sql
-- Analyze spatial index usage
EXPLAIN (ANALYZE, BUFFERS) 
SELECT * FROM properties 
WHERE ST_DWithin(location::geography, ST_SetSRID(ST_MakePoint(-122.4194, 37.7749), 4326)::geography, 1000);
```

## Implementation Steps
1. Set up PostGIS extensions and spatial indexes
2. Load and validate geographic data
3. Implement spatial query patterns for your use case
4. Optimize with appropriate index types (GiST, SP-GiST)
5. Test with production-scale data volumes

## Best Practices
- Always use geography type for distance calculations (meters, not degrees)
- Create GiST indexes on geometry columns
- Use ST_DWithin instead of ST_Distance < X for index utilization
- Batch-load data with COPY for large datasets
- Monitor index bloat and VACUUM regularly
